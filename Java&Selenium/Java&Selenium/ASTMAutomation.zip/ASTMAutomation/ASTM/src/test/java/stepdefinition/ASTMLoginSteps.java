package stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import pageobject.ASTMLoginPage;

public class ASTMLoginSteps {
    private WebDriver driver = stepdefinition.Hooks.driver;
    ASTMLoginPage astmLoginPage = new ASTMLoginPage(driver);

    @Given("user is on the ASTM login page")
    public void user_is_on_the_astm_login_page()  {
        stepdefinition.Hooks.launchApplication();
        astmLoginPage.clickLicenceAgreement();
    }
    @When("user enters valid credentials")
    public void user_enters_valid_credentials() {
        astmLoginPage.enterUsername();
        astmLoginPage.enterPassword();
    }
    @Then("click on login button")
    public void click_on_login_button() {
        astmLoginPage.clickLoginButton();
    }
    @And("select Component {string}")
    public void selectComponent(String reqOption) {
        astmLoginPage.selectComponentAstm(reqOption);
    }

    @And("click on menu {string}")
    public void clickOnMenu(String arg0) {
        astmLoginPage.selectMenu(arg0);
    }


    @When("select from Dropdown {string}")
    public void selectFromDropdown(String arg0)  {
        astmLoginPage.selDropDown(arg0);
    }

    @Then("User click on LogOut")
    public void userClickOnLogOut() {
        astmLoginPage.logOutApplication();
    }
}
