package pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import stepdefinition.Hooks;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ASTMLoginPage {
    private WebDriver driver = Hooks.driver;
    private WebDriverWait wait;  // Global WebDriverWait

    // Constructor - Initialize WebDriverWait
    public ASTMLoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(50)); // Global WebDriverWait initialization
    }

    private String clickAgree = "//button[text()='Agree and Continue']";
    private String signIN = "(//span[text()='Sign In/Register'])[2]";
    private By usernameInput = By.xpath("//input[@id='userName']");
    private By passwordInput = By.xpath("//input[@id='encPass']");
    private By loginButton = By.xpath("//button[text()='Sign In']");
    private By menu = By.xpath("//span[text()='Menu']");
    private String selectComponent = "//a[text()='%s']";
    private String selectASTMbtn = "//span[text()='%s']/following-sibling::button";
    private By selectDropdown = By.xpath("//div[@class='sort-by astm-type-body']");
    private String clickDesignation = "//a[text()='%s']";
    private By designationColData = By.xpath("//table[@class='table astm-table table-striped table table-hover']//tbody[2]//tr//td[1]/span");
    private By sortingIcon = By.xpath("//*[@id='app-view-container']//*[name()='svg'][contains(@class, 'bi-arrow-down')]");
    private By logOutUser = By.xpath("//li[@id='account_menu_ipad']/a[2]/div");
    private By logoutApp = By.xpath("//*[@id='account_menu_ipad_logout']/span");

    // Helper method to click elements using JavaScript
    private void clickElement(By element) {
        WebElement loc = driver.findElement(element);
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].click();", loc);
    }

    public void clickLicenceAgreement()  {
        List<WebElement> agree = driver.findElements(By.xpath(clickAgree));
        if (!agree.isEmpty()) {
            JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
            jsExecutor.executeScript("arguments[0].click();", agree.get(1));
            clickElement(By.xpath(signIN));
        }

    }

    public void enterUsername() {
        wait.until(ExpectedConditions.elementToBeClickable(usernameInput)); // Using global WebDriverWait
        driver.findElement(usernameInput).sendKeys(Hooks.user);
    }

    public void enterPassword() {
        driver.findElement(passwordInput).sendKeys(Hooks.pass);
    }

    public void clickLoginButton() {
        clickElement(loginButton);
    }

    public void selectComponentAstm(String reqOption) {
        wait.until(ExpectedConditions.jsReturnsValue("return document.readyState==\"complete\";"));

        try{
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath(String.format(selectASTMbtn, reqOption))));
            clickElement(By.xpath(String.format(selectASTMbtn, reqOption)));
        }catch (Exception ignored){
            System.out.println("Options are not displayed");
        }
    }

    public void selectMenu(String element) {
        clickElement(menu);
        clickElement(By.xpath(String.format(selectComponent, element)));
    }

    public void selDropDown(String value)  {
        wait.until(ExpectedConditions.elementToBeClickable(selectDropdown));
        clickElement(selectDropdown);
        clickElement(By.xpath(String.format(clickDesignation, value)));
        //wait.until(ExpectedConditions.jsReturnsValue("return document.readyState==\"complete\";"));
        List<WebElement> colData = driver.findElements(designationColData);
        verifyTableDataSorting(colData, "descending");

        WebElement downArrow = driver.findElement(sortingIcon);
        //downArrow.click();
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].dispatchEvent(new MouseEvent('click', { bubbles: true }))", downArrow);

        verifyTableDataSorting(colData, "ascending");
    }

    public void verifyTableDataSorting(List<WebElement> elements, String sortingOrder) {
        try{
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        List<String> actualColData = new ArrayList<>();
        for (WebElement colData : elements) {
            actualColData.add(colData.getText().trim());
        }
        System.out.println("Actual  col data " + actualColData);

        List<String> sortedList = new ArrayList<>(actualColData);
        if (sortingOrder.equalsIgnoreCase("ascending")) {
            Collections.sort(sortedList);
        } else {
            Collections.sort(sortedList, Collections.reverseOrder());
        }
        System.out.println("Sorted List " + sortedList);


        boolean isEqual = sortedList.equals(actualColData);

        if (isEqual) {
            System.out.println("Designation column data is sorted in " + sortingOrder + " order");
        } else {
            System.out.println("Designation column data is not sorted in " + sortingOrder + " order");
        }
    }

    public void logOutApplication() {
        clickElement(logOutUser);
        clickElement(logoutApp);
    }
}
