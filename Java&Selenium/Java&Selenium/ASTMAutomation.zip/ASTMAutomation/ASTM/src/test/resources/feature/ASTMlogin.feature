Feature:Verify Compass Points Admin Screen


  Scenario: verify sorting functionality using designation option
    Given  user is on the ASTM login page
    When   user enters valid credentials
    Then   click on login button
    And    select Component "ASTM International"
    And    click on menu "Compass Points Admin"
    When   select from Dropdown "Designation"
    Then   User click on LogOut