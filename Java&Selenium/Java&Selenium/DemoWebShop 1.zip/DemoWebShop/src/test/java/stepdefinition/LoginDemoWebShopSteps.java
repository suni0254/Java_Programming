package stepdefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import pageobject.LoginDemoWebShopPage;

public class LoginDemoWebShopSteps {
    private WebDriver driver = stepdefinition.Hooks.driver;
    LoginDemoWebShopPage lp = new LoginDemoWebShopPage(driver);

    @Given("the user is on the Demo Web Shop login page")
    public void the_user_is_on_the_demo_web_shop_login_page() {
        stepdefinition.Hooks.launchApplication();
        lp.DemoWebShopElement();
    }
    @When("the user enters valid credentials")
    public void the_user_enters_valid_credentials() {
        lp.enterUsername();
        lp.enterPassword();
    }
    @When("clicks the login button")
    public void clicks_the_login_button() {
        lp.clickLoginButton();
    }
    @Then("the user should be logged in successfully")
    public void the_user_should_be_logged_in_successfully() {
        lp.pageHeaderName();
    }

    @When("user able to click on Books workFlow")
    public void userAbleToClickOnBooksWorkFlow() {
        lp.booksWorkFlow("Books");
    }

    @And("user able to click on sort by dropDown")
    public void userAbleToClickOnSortByDropDown() {
        lp.selectItemFromDropdown("dropDown","Name: A to Z","pageDropDown","12","pageDropDown1","Grid");

    }

    @Given("user able to add to cart")
    public void userAbleToAddToCart() throws InterruptedException {
        lp.addToCart("Fiction");
    }

    @And("user able to verify page HeaderName")
    public void userAbleToVerifyPageHeaderName()  {

        lp.verifyPageHeaderName();
    }

    @When("user able to select shipping method")
    public void userAbleToSelectShippingMethod() {
        lp.shippingMethod("opc-billing","opc-shipping","opc-shipping_method","opc-payment_method","opc-payment_info","opc-confirm_order");
    }

    @Then("user able to successfully click right product")
    public void userAbleToSuccessfullyClickRightProduct() {
        lp.verifySuccessProduct();
    }


    @Then("verify the {string} mail on home page")
    public void verifyTheMailOnHomePage(String mailName) {
        lp.verifyLogo(mailName);
    }

    @Then("verify the {string} headerPage")
    public void verifyTheHeaderPage(String shoppingCartName) throws InterruptedException {
        lp.booksWorkFlow("Books");
        lp.selectItemFromDropdown("dropDown","Name: A to Z","pageDropDown","8","pageDropDown1","Grid");
        lp.addToCart1("Fiction");
        lp.verifyShoppingCart(shoppingCartName);
    }


}
