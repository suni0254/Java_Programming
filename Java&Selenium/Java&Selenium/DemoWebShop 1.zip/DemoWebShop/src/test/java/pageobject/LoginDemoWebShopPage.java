package pageobject;

import io.netty.bootstrap.Bootstrap;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import stepdefinition.Hooks;

import java.time.Duration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class LoginDemoWebShopPage {
    private WebDriver driver = Hooks.driver;

    public LoginDemoWebShopPage(WebDriver driver) {

        PageFactory.initElements(driver, this);
    }

    private By loginElement = By.xpath("//a[text()='Log in']");
    private By usernameInput = By.xpath("//input[@id='Email']");
    private By passwordInput = By.xpath("//input[@id='Password']");
    private By loginButton = By.xpath("//input[@value='Log in']");

    private By headerName = By.xpath("//div[@class='header-logo']");

    public void enterUsername() {

        driver.findElement(usernameInput).sendKeys(Hooks.user);
    }

    public void enterPassword() {

        driver.findElement(passwordInput).sendKeys(Hooks.pass);
    }

    public void clickLoginButton() {

        driver.findElement(loginButton).click();
    }

    public void DemoWebShopElement() {
        driver.findElement(loginElement).click();
    }

    public void pageHeaderName() {
        driver.findElement(headerName).isDisplayed();
    }

    private String booksEle = "//div[@class='header-menu']/following::a[normalize-space(text())='%s']";

    public void booksWorkFlow(String selElement) {
        By loc = By.xpath(String.format(booksEle, selElement));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(loc)).click();
    }

    private String dropDown = "//select[@id='products-orderby']";

    private String dropDownOption = "//option[text()='%s']";
    private String pageDropDown = "//select[@id='products-pagesize']";
    private String numDropDown = "//option[text()='%s']";
    private String pageDropDown1 = "//select[@id='products-viewmode']";
    private String numDropDown1 = "//option[text()='%s']";

    public void selectItemFromDropdown(String sDropdownItem, String sSearchValue, String sDropdownItem1, String sSearchValue1, String sDropdownItem2, String sSearchValue2) {
        //driver.findElement(By.xpath(String.format(StageDropDown,sDropdownItem)));
        By locTxtDropDown = By.xpath(String.format(dropDown, sDropdownItem));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(locTxtDropDown)).click();
        driver.findElement(By.xpath(String.format(dropDownOption, sSearchValue))).click();

        By locTxtDropDown1 = By.xpath(String.format(pageDropDown, sDropdownItem1));
        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait1.until(ExpectedConditions.visibilityOfElementLocated(locTxtDropDown1)).click();
        driver.findElement(By.xpath(String.format(numDropDown, sSearchValue1))).click();

        By locTxtDropDown2 = By.xpath(String.format(pageDropDown1, sDropdownItem2));
        WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait2.until(ExpectedConditions.visibilityOfElementLocated(locTxtDropDown2)).click();
        driver.findElement(By.xpath(String.format(numDropDown1, sSearchValue2))).click();


    }

    //private String addCart = "//a[text()='%s']/../../child::div/div[@class='buttons']";
    private String addCart = "//a[text()='%s']/../following-sibling::div/div/input[@value='Add to cart']";
    private String verifyElement = "//div[@id='bar-notification']";
    private String shoppingCart = "//span[text()='Shopping cart']";
    private String checkBox = "//input[@id='termsofservice']";
    private String checkOut = "//button[@id='checkout']";

    public void addToCart(String sAddCart) throws InterruptedException {
        Actions actions = new Actions(driver);
        //actions.moveToElement(driver.findElement(By.xpath("(//input[@value='Add to cart'])[2]"))).perform();
        //actions.click();
        actions.moveToElement(driver.findElement(By.xpath(String.format(addCart, sAddCart)))).perform();
        driver.findElement(By.xpath(String.format(addCart, sAddCart))).click();
        // By AddToCart = By.xpath(String.format(addCart, addSelect));
        // WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(20));
        // wait3.until(ExpectedConditions.visibilityOfElementLocated(AddToCart));
        // driver.findElement(By.xpath(String.format(addCart,addSelect))).click();

        driver.findElement(By.xpath(String.format(verifyElement))).isDisplayed();
        driver.findElement(By.xpath(String.format(shoppingCart))).click();
        driver.findElement(By.xpath(String.format(checkBox))).click();
        driver.findElement(By.xpath(String.format(checkOut))).click();
    }

    private String pageHeaderName = "//h2[text()='Billing address']";


    public void verifyPageHeaderName() {
        driver.findElement(By.xpath(String.format(pageHeaderName))).isDisplayed();
    }

    private String countinue = "//div[@class='page-body checkout-data']//li[@id='%s']//div[@class='buttons']/input";

    public void shippingMethod(String selectValue, String selectValue1, String selectValue2, String selectValue3, String selectValue4, String selectValue5) {
        By shippingMethod1 = By.xpath(String.format(countinue, selectValue));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(shippingMethod1)).click();

        driver.findElement(By.xpath(String.format(countinue, selectValue1))).click();
        driver.findElement(By.xpath(String.format(countinue, selectValue2))).click();
        driver.findElement(By.xpath(String.format(countinue, selectValue3))).click();
        driver.findElement(By.xpath(String.format(countinue, selectValue4))).click();
        driver.findElement(By.xpath(String.format(countinue, selectValue5))).click();

    }

    private String verifyProduct = "//h1[text()='Thank you']";

    public void verifySuccessProduct() {

        driver.findElement(By.xpath(String.format(verifyProduct))).click();
    }

    private String mailHeader = "//a[@href='/customer/info' and text()='sunkarinaresh576@gmail.com']";

    public void verifyLogo(String logoName) {
        String mailText = driver.findElement(By.xpath(mailHeader)).getText();
        System.out.println(mailText);
        Assert.assertEquals(logoName, mailText);
    }
    private String addCart1 = "//h1[text()='Shopping cart']";
    public void verifyShoppingCart(String sCartName) {
        String sText = driver.findElement(By.xpath(addCart1)).getText();
        System.out.println(sText);
        Assert.assertEquals(sCartName, sText);
    }
    public void addToCart1(String sAddCart) throws InterruptedException {
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(By.xpath(String.format(addCart, sAddCart)))).perform();
        driver.findElement(By.xpath(String.format(addCart, sAddCart))).click();
        driver.findElement(By.xpath(String.format(shoppingCart))).click();

    }
}



