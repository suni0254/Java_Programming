Feature: Demo Web Shop Testing

@Test1
  Scenario: User can log in
    Given the user is on the Demo Web Shop login page
    When the user enters valid credentials
    And clicks the login button
    Then the user should be logged in successfully
    When user able to click on Books workFlow
    And user able to click on sort by dropDown
    Given user able to add to cart
    And user able to verify page HeaderName
    When user able to select shipping method
    Then user able to successfully click right product
  @Case1
  Scenario:  Verify the Demo Web Shop Logo
    Given the user is on the Demo Web Shop login page
    When the user enters valid credentials
    And clicks the login button
    Then verify the "sunkarinaresh576@gmail.com" mail on home page

  @Case2
  Scenario:  Verify the Demo Web Shop Logo
    Given the user is on the Demo Web Shop login page
    When the user enters valid credentials
    And clicks the login button
    Then verify the "sunkarinaresh576@gmail.com" mail on home page
    Then verify the "Shopping cart" headerPage

